import numpy as np
import wave
import subprocess
import os
import tempfile

def binary_array_to_wav(binary_array, frame_duration, sample_rate=44100, noise_amplitude=0.5):
    # Calculate the number of audio samples per frame
    samples_per_frame = int(sample_rate * frame_duration)

    # Initialize the audio signal array for the entire video
    total_samples = len(binary_array) * samples_per_frame
    audio_signal = np.zeros(total_samples, dtype=np.float32)

    # Generate white noise where binary array is 1
    for i, value in enumerate(binary_array):
        if value == 1:
            # Add white noise for this frame
            noise = np.random.uniform(-1, 1, samples_per_frame) * noise_amplitude
            audio_signal[i * samples_per_frame:(i + 1) * samples_per_frame] = noise

    # Normalize the signal to the max value of int16 (for .wav format)
    audio_signal = (audio_signal * np.iinfo(np.int16).max).astype(np.int16)

    # Create a temporary file to hold the wav data
    wav_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")

    # Write the audio signal to the temporary .wav file
    with wave.open(wav_file.name, 'w') as wav:
        n_channels = 1  # Mono sound
        sampwidth = 2  # Number of bytes per sample (int16 -> 2 bytes)
        wav.setnchannels(n_channels)
        wav.setsampwidth(sampwidth)
        wav.setframerate(sample_rate)
        wav.writeframes(audio_signal.tobytes())

    return wav_file.name

def add_sync_to_video(binary_array, video_path, output_video_path, frame_duration):
    wav_temp_file = binary_array_to_wav(binary_array, frame_duration)
    try:
        # Run FFmpeg and capture stdout and stderr
        result = subprocess.run([
            'ffmpeg', '-y', '-i', video_path, '-i', wav_temp_file,
            '-c:v', 'copy', '-c:a', 'aac', '-strict', 'experimental', output_video_path
        ], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        # Print FFmpeg output (success case)
        print(result.stdout)

    except subprocess.CalledProcessError as e:
        # Print FFmpeg error message (failure case)
        print(f"FFmpeg failed with error: {e.stderr}")
    finally:
        os.remove(wav_temp_file)