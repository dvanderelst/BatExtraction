import numpy as np
from Library import AudioHDF5
from Library import AudioSignal
from matplotlib import pyplot as plt
import pandas as pd

start_file = 120
end_file = 130
rms_segment_size = 400 * 10
low_khz = 30
high_khz = 150
db_cutoff = -25

segments_found = 0
audio_output_folder = '/media/dieter/Extreme SSD/processed_audio'

rms_results =[]
selected_segments = []
for chunk_nr in range(start_file, end_file):
    print('Processing chunk:', chunk_nr, 'of max.', end_file)
    data_chunk = AudioHDF5.read_channel_data(audio_output_folder, channel_idx=21, chunk_nr=chunk_nr)
    data_chunk = data_chunk - np.median(data_chunk)
    data_chunk = AudioSignal.bandpass_filter(data_chunk, low_khz * 1000, high_khz * 1000)

    chunk_length = len(data_chunk)
    steps = chunk_length // rms_segment_size
    rms_values = np.zeros(steps)
    for segment_nr in range(0, steps):
        start_index = segment_nr * rms_segment_size
        end_index = (segment_nr + 1) * rms_segment_size
        segment = data_chunk[start_index:end_index]
        rms = np.sqrt(np.mean(segment ** 2))
        rms = 10 * np.log10(rms)
        result = [chunk_nr, segment_nr, rms]
        rms_results.append(result)

        if rms > db_cutoff: selected_segments.append(segment)

results = pd.DataFrame(rms_results, columns=['chunk_nr', 'segment_nr', 'rms'])
#%%
plt.figure()
plt.boxplot(results['rms'])
plt.show()

for i in range(0, len(selected_segments)):
    plt.figure()
    plt.specgram(selected_segments[i], Fs=400000, NFFT=64, noverlap=63)
    plt.colorbar()
    plt.show()


    #     if np.max(rms_values) > db_cutoff:
    #         segments_found += 1
    #         print(f"Segment {segment_nr} in chunk {file_nr}  has high RMS value")
    #         print(segments_found)
    #         plt.figure()
    #         plt.plot(segment)
    #         plt.show()
    #
    #         # Plot a spectrogram of segment
    #         plt.figure()
    #         plt.specgram(segment, Fs=400000, NFFT=64, noverlap=63)
    #         plt.colorbar()
    #         plt.show()
    #         break
    #
    # if segments_found > 0:break
